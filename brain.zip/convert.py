import os
import pydicom
from PIL import Image
import pdb


def convert_dcm_to_jpg(dcm_folder, output_folder):
    """
    将指定文件夹及其子文件夹中的所有DICOM文件转换为JPG格式。

    :param dcm_folder: 包含DICOM文件的文件夹路径
    :param output_folder: 输出JPG文件的文件夹路径
    """
    # 确保输出文件夹存在
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

        # 遍历文件夹及其子文件夹
    for root, dirs, files in os.walk(dcm_folder):
        #pdb.set_trace()
        for file in files:
            if file.lower().endswith('.ima'):
                # 构造完整的文件路径
                file_path = os.path.join(root, file)
                # 读取DICOM文件
                dcm_data = pydicom.dcmread(file_path)
                # 获取图像数据
                image_data = dcm_data.pixel_array
                # 使用Pillow库将图像数据转换为JPG
                image = Image.fromarray(image_data)
                if image.mode != 'RGB':
                    image = image.convert('RGB')
                    # 构造输出JPG文件的路径
                out2 = output_folder + '/' + root.split("\\")[1]
                if not os.path.exists(out2):
                    os.makedirs(out2)
                output_path = os.path.join(out2, os.path.splitext(file)[0] + '.jpg')
                #print (file_path, output_path)
                #pdb.set_trace()
                # 保存JPG文件
                image.save(output_path)
                print(f'Converted {file_path} to {output_path}')

            # 使用示例


if __name__ == "__main__":
    dcm_folder = './A'  # 替换为你的DICOM文件所在的文件夹路径
    output_folder = './trainA'  # 替换为你想要保存JPG文件的文件夹路径
    convert_dcm_to_jpg(dcm_folder, output_folder)
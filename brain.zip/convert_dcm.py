import os
import pydicom
from PIL import Image
import imageio
import pdb
import numpy as np


def convert_dcm_to_jpg(dcm_folder, output_folder):
    """
    将指定文件夹及其子文件夹中的所有DICOM文件转换为JPG格式。

    :param dcm_folder: 包含DICOM文件的文件夹路径
    :param output_folder: 输出JPG文件的文件夹路径
    """
    # 确保输出文件夹存在
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

        # 遍历文件夹及其子文件夹
    for root, dirs, files in os.walk(dcm_folder):
        #pdb.set_trace()
        for file in files:
            if file.lower().endswith('.dcm'):
                # 构造完整的文件路径
                file_path = os.path.join(root, file)
                # 读取DICOM文件
                ds = pydicom.read_file(file_path)
                # 尝试从DICOM元数据中获取窗宽和窗位值
                try:
                    window_center, window_width = ds.WindowCenter, ds.WindowWidth
                except AttributeError:
                    # 如果DICOM没有窗宽和窗位信息，使用默认值或自定义
                    window_center, window_width = np.median(ds.pixel_array), np.max(ds.pixel_array) - np.min(
                        ds.pixel_array)
                # 转换为numpy数组
                pixel_array_numpy = ds.pixel_array.astype(float)
                # 将像素值调整到窗宽和窗位
                pixel_array_numpy = pixel_array_numpy - (window_center - window_width / 2)
                pixel_array_numpy = np.clip(pixel_array_numpy, 0, window_width)
                pixel_array_numpy = pixel_array_numpy / window_width * 255.0

                # 转换为整型
                pixel_array_numpy = np.uint8(pixel_array_numpy)
                # 将numpy数组转换为Pillow图片格式
                image = Image.fromarray(pixel_array_numpy)
                    # 构造输出JPG文件的路径
                out2 = output_folder + '/' + root.split("\\")[1]
                if not os.path.exists(out2):
                    os.makedirs(out2)
                output_path = os.path.join(out2, os.path.splitext(file)[0] + '.jpg')
                # 保存JPG文件
                image.save(output_path)
                print(f'Converted {file_path} to {output_path}')

            # 使用示例


if __name__ == "__main__":
    dcm_folder = './B'  # 替换为你的DICOM文件所在的文件夹路径
    output_folder = './trainB'  # 替换为你想要保存JPG文件的文件夹路径
    convert_dcm_to_jpg(dcm_folder, output_folder)